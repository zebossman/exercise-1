# Warmup in Racket

This in-class exercise is meant to be completed in groups of two or
three students. The assignment consists of four fuctions, each within
the file `warmup.rkt` (all projects in this class will modify one
file). These functions are currently "stubbed out"--a partial template
is provided, but some aspects have been marked `'todo`, you will fill
in these portions with your solutions.

You **must** use the git interface to submit this assignment. To
submit your code you will need to do the following:

```
git add warmup.rkt
git commit -m <commit message>
git push
```

# Project

Comments in `warmup.rkt` specify what you must do, but you should read
the public tests (described subsequently) to understand specific
examples. There are three easier functions, `euclid-distance`,
`contains-less-than`, and `shape-area`, which should be doable without
recursion. A last function, `draw-ascii-line`, renders an
ASCII-line. You will extend this function for the first project to
render 2D ASCII images.

# Testing

This project has 11 public tests and 0 secret tests. You should be
able to see all of the tests, and you are strongly encouraged to read
the public tests and ensure your program works on them. Subsequent
projects will include secret tests.

To test your code, use `tester.py`. It sis invoked as follows:

```
[kmicinski] warmup % python3 tester.py
usage: tester.py [-h] [--list] [--all] [--verbose] [--test TEST]

optional arguments:
  -h, --help            show this help message and exit
  --list, -l            List available tests
  --all, -a             Perform all tests
  --verbose, -v         View test stdout, verbose output
  --test TEST, -t TEST  Perform a specific testname (case sensitive)
```

To run all tests we can then do `python3 tester.py -av`, which invokes
`tester.py` (the test script) with the two options `-a` (perform all
tests) and `-v` (dump verbose output). You can run a specific test
with, e.g., `python3 tester.py -vt public-ascii-0`.

You should get in the habit of reading the public tests for yourself:
this will make it much easier to figure out why your code fails the
test. To do this you should look at the corresponding directory to the
test in the `tests/` subdirectory--this directory contains all public
tests (which are reset to their original contents within the Docker
container on the autograder). For example, if you fail
`public-ascii-0`, you should go read `tests/public-ascii-0/test.rkt`
(this code is invoked via `driver.py`). You can also see the expected
output in the corresponding `answer` file.

# Submitting your code for testing

Once you have done a git commit and push, go to the autograder and
select for your project to be graded.
